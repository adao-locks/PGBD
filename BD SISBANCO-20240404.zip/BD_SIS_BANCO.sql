CREATE DATABASE  IF NOT EXISTS `bd_sis_banco` /*!40100 DEFAULT CHARACTER SET utf8mb3 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `bd_sis_banco`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: bd_sis_banco
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_agencia`
--

DROP TABLE IF EXISTS `tb_agencia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_agencia` (
  `idTB_AGENCIA` int NOT NULL AUTO_INCREMENT,
  `NomeAgencia` varchar(45) NOT NULL,
  `FKidTB_BANCO` int NOT NULL,
  PRIMARY KEY (`idTB_AGENCIA`),
  UNIQUE KEY `idTB_AGENCIA_UNIQUE` (`idTB_AGENCIA`),
  KEY `fk_TB_AGENCIA_TB_BANCO_idx` (`FKidTB_BANCO`),
  CONSTRAINT `fk_TB_AGENCIA_TB_BANCO` FOREIGN KEY (`FKidTB_BANCO`) REFERENCES `tb_banco` (`idTB_BANCO`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_agencia`
--

LOCK TABLES `tb_agencia` WRITE;
/*!40000 ALTER TABLE `tb_agencia` DISABLE KEYS */;
INSERT INTO `tb_agencia` VALUES (1,'Centro',1),(2,'Itaipava',1),(3,'Metro',1),(4,'Justiça do Trabalho',1),(5,'São Luiz',1),(6,'Centro',2),(7,'Tribunal de Justiça',2),(8,'Centro',3),(9,'Garcia',3),(10,'Vitor Konder',3),(11,'Centro',4),(12,'Itaim',4),(13,'Salto do Norte',4),(14,'Fidélis',4),(15,'Fortaleza',4);
/*!40000 ALTER TABLE `tb_agencia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_banco`
--

DROP TABLE IF EXISTS `tb_banco`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_banco` (
  `idTB_BANCO` int NOT NULL AUTO_INCREMENT,
  `NomeBanco` varchar(45) NOT NULL,
  PRIMARY KEY (`idTB_BANCO`),
  UNIQUE KEY `idTB_BANCO_UNIQUE` (`idTB_BANCO`),
  UNIQUE KEY `NomeBanco_UNIQUE` (`NomeBanco`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_banco`
--

LOCK TABLES `tb_banco` WRITE;
/*!40000 ALTER TABLE `tb_banco` DISABLE KEYS */;
INSERT INTO `tb_banco` VALUES (1,'Banco do Brasil'),(4,'Bradesco'),(2,'Caixa Econômica Federal'),(3,'Itaú');
/*!40000 ALTER TABLE `tb_banco` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_cliente`
--

DROP TABLE IF EXISTS `tb_cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_cliente` (
  `idTB_CLIENTE` int NOT NULL AUTO_INCREMENT,
  `NomeCliente` varchar(45) NOT NULL,
  `SobrenomeCliente` varchar(45) NOT NULL,
  `RGCliente` int NOT NULL,
  `DTNascimento` date NOT NULL,
  PRIMARY KEY (`idTB_CLIENTE`),
  UNIQUE KEY `idTB_CLIENTE_UNIQUE` (`idTB_CLIENTE`),
  UNIQUE KEY `RGCliente_UNIQUE` (`RGCliente`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_cliente`
--

LOCK TABLES `tb_cliente` WRITE;
/*!40000 ALTER TABLE `tb_cliente` DISABLE KEYS */;
INSERT INTO `tb_cliente` VALUES (1,'Arnaldo','Antunes',11111,'2000-10-11'),(2,'Celso','Elias',22222,'1985-09-01'),(3,'Antônio ','Nicolai',33333,'1988-10-09'),(4,'Maria','Santos',44444,'1988-02-09'),(5,'Marcos','Silva',55555,'1987-01-09'),(6,'Gabriel ','Medeiros',6666,'1999-10-25'),(7,'Marcos','Medina',77777,'1998-11-29'),(8,'Beatriz','Medina',8888,'1988-11-09'),(9,'Hélcio','Fábris',9999,'1987-12-10'),(10,'Maycon','Silva',101010,'1984-09-09'),(11,'Matheus','Santana',2020202,'1985-02-11'),(12,'Maria','Norielli',3030303,'1986-03-09');
/*!40000 ALTER TABLE `tb_cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_conta`
--

DROP TABLE IF EXISTS `tb_conta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_conta` (
  `idTB_CONTA` int NOT NULL AUTO_INCREMENT,
  `NumeroConta` int NOT NULL,
  `FKidTB_AGENCIA` int NOT NULL,
  `FKidTB_CLIENTE` int NOT NULL,
  PRIMARY KEY (`idTB_CONTA`),
  UNIQUE KEY `idTB_CONTA_UNIQUE` (`idTB_CONTA`),
  KEY `fk_TB_CONTA_TB_AGENCIA1_idx` (`FKidTB_AGENCIA`),
  KEY `fk_TB_CONTA_TB_CLIENTE1_idx` (`FKidTB_CLIENTE`),
  CONSTRAINT `fk_TB_CONTA_TB_AGENCIA1` FOREIGN KEY (`FKidTB_AGENCIA`) REFERENCES `tb_agencia` (`idTB_AGENCIA`),
  CONSTRAINT `fk_TB_CONTA_TB_CLIENTE1` FOREIGN KEY (`FKidTB_CLIENTE`) REFERENCES `tb_cliente` (`idTB_CLIENTE`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_conta`
--

LOCK TABLES `tb_conta` WRITE;
/*!40000 ALTER TABLE `tb_conta` DISABLE KEYS */;
INSERT INTO `tb_conta` VALUES (1,23232,1,5),(2,65656,4,1),(3,76766,1,2),(4,65557,2,7),(5,898988,2,9),(6,78787,3,10),(7,676777,5,11),(8,787877,4,3),(9,545454,9,1),(10,11222,2,4),(11,99800,10,5),(12,70098,9,6),(13,13321,4,6),(14,9989,4,8),(15,787888,2,12);
/*!40000 ALTER TABLE `tb_conta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_controle_emprestimo`
--

DROP TABLE IF EXISTS `tb_controle_emprestimo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_controle_emprestimo` (
  `idTB_EMPRESTIMO` int NOT NULL AUTO_INCREMENT,
  `Juros` int NOT NULL,
  `Parcelas` int NOT NULL,
  `ValorParcela` double(10,2) NOT NULL,
  `FKidTB_OPERACAO` int NOT NULL,
  PRIMARY KEY (`idTB_EMPRESTIMO`),
  UNIQUE KEY `idTB_EMPRESTIMO_UNIQUE` (`idTB_EMPRESTIMO`),
  KEY `fk_TB_EMPRESTIMO_TB_OPERACAO1_idx` (`FKidTB_OPERACAO`),
  CONSTRAINT `fk_TB_EMPRESTIMO_TB_OPERACAO1` FOREIGN KEY (`FKidTB_OPERACAO`) REFERENCES `tb_operacao` (`idTB_OPERACAO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_controle_emprestimo`
--

LOCK TABLES `tb_controle_emprestimo` WRITE;
/*!40000 ALTER TABLE `tb_controle_emprestimo` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb_controle_emprestimo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_operacao`
--

DROP TABLE IF EXISTS `tb_operacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_operacao` (
  `idTB_OPERACAO` int NOT NULL AUTO_INCREMENT,
  `DTOperacao` datetime NOT NULL,
  `ValorOperacao` double(10,2) NOT NULL,
  `FKidTB_CONTA` int NOT NULL,
  `FKidTB_TIPOOPERACAO` int NOT NULL,
  PRIMARY KEY (`idTB_OPERACAO`),
  UNIQUE KEY `idTB_OPERACAO_UNIQUE` (`idTB_OPERACAO`),
  KEY `fk_TB_OPERACAO_TB_CONTA1_idx` (`FKidTB_CONTA`),
  KEY `fk_TB_OPERACAO_TB_TIPOOPERACAO1_idx` (`FKidTB_TIPOOPERACAO`),
  CONSTRAINT `fk_TB_OPERACAO_TB_CONTA1` FOREIGN KEY (`FKidTB_CONTA`) REFERENCES `tb_conta` (`idTB_CONTA`),
  CONSTRAINT `fk_TB_OPERACAO_TB_TIPOOPERACAO1` FOREIGN KEY (`FKidTB_TIPOOPERACAO`) REFERENCES `tb_tipooperacao` (`idTB_TIPOOPERACAO`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_operacao`
--

LOCK TABLES `tb_operacao` WRITE;
/*!40000 ALTER TABLE `tb_operacao` DISABLE KEYS */;
INSERT INTO `tb_operacao` VALUES (1,'2022-11-10 10:00:00',500.00,3,2),(2,'2022-11-18 12:00:00',300.00,2,2),(3,'2022-11-18 14:00:00',150.00,1,2),(4,'2022-11-21 10:00:00',200.00,4,2),(5,'2022-11-29 09:00:00',500.00,5,2),(6,'2022-12-10 12:00:00',700.00,6,2),(7,'2022-12-10 12:00:00',100.00,1,1),(8,'2022-12-18 11:00:00',90.00,2,1),(9,'2022-12-21 10:00:00',70.00,3,1),(10,'2022-12-21 13:00:00',300.00,9,2),(11,'2022-12-29 11:00:00',400.00,8,2),(12,'2022-12-29 11:00:00',200.00,7,2),(13,'2022-12-29 15:00:00',250.00,10,2),(14,'2023-01-10 10:00:00',100.00,9,1),(15,'2023-01-10 13:00:00',125.00,8,1),(16,'2023-01-10 13:00:00',2000.00,1,4),(17,'2023-01-18 12:00:00',5000.00,2,4),(18,'2023-01-18 16:00:00',400.00,11,2),(19,'2023-02-05 10:00:00',200.00,12,2),(20,'2023-02-06 12:00:00',600.00,13,2),(21,'2023-02-07 14:00:00',200.00,13,3),(22,'2023-02-07 14:00:00',200.00,13,1),(23,'2023-02-07 14:00:00',200.00,14,2);
/*!40000 ALTER TABLE `tb_operacao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_tipooperacao`
--

DROP TABLE IF EXISTS `tb_tipooperacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_tipooperacao` (
  `idTB_TIPOOPERACAO` int NOT NULL AUTO_INCREMENT,
  `NomeTipoOperacao` varchar(45) NOT NULL,
  PRIMARY KEY (`idTB_TIPOOPERACAO`),
  UNIQUE KEY `idTB_TIPOOPERACAO_UNIQUE` (`idTB_TIPOOPERACAO`),
  UNIQUE KEY `NomeTipoOperacao_UNIQUE` (`NomeTipoOperacao`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_tipooperacao`
--

LOCK TABLES `tb_tipooperacao` WRITE;
/*!40000 ALTER TABLE `tb_tipooperacao` DISABLE KEYS */;
INSERT INTO `tb_tipooperacao` VALUES (2,'Depósito'),(4,'Empréstimo'),(1,'Saque'),(3,'Transferência');
/*!40000 ALTER TABLE `tb_tipooperacao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'bd_sis_banco'
--

--
-- Dumping routines for database 'bd_sis_banco'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-14  7:52:58
